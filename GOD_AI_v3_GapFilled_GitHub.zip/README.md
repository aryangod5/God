# GOD AI v3 — Local Agent Foundation

This is a clean rebuild intended for GitHub Actions -> APK.

## Important truth
This project is designed around:
- local GGUF LLM inference
- offline speech recognition
- local memory
- deterministic calculator
- bounded agent planning
- web retrieval
- safe Android intents
- futuristic HUD

It does NOT magically provide frontier-ChatGPT intelligence offline. The phone's hardware and Android security impose limits.

The model is downloaded at runtime; it is NOT packed into the APK.

## GitHub build
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open Actions.
4. Run "Build GOD AI APK".
5. Download the APK artifact.

## Runtime
On first launch GOD downloads a small local model and Vosk speech model. Internet is only used for those downloads and optional web research.

## Android limitations
- A completely powered-off phone cannot run an ordinary app.
- Background microphone operation is subject to Android/OEM restrictions.
- Accessibility automation requires the user to explicitly enable the service.
- Some actions can only open a system/app screen rather than perform the action directly.

## Architecture
Local LLM -> planner -> tools -> verifier -> answer -> TTS.

Tools included in this foundation:
- Calculator
- Web search/retrieval
- Memory/retrieval
- Android intents
- File text import
- Agent planner
