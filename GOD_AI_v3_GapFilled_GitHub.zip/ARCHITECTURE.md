# GOD AI v3 Architecture / Gap-Filling Tricks

## Core principle
Do not ask one small LLM to do everything.

Use:
- LLM = language/reasoning
- tools = exact capabilities
- memory = persistence
- retrieval = long context
- planner = multi-step work
- verifier = reduce hallucination

## Planned expansion layers

### 1. Model router
Select 0.5B/1.5B/3B GGUF based on RAM and task complexity.

### 2. RAG memory
Store conversation/document chunks and retrieve only relevant chunks.

### 3. Research agent
Search -> open -> extract -> compare -> cite -> answer.

### 4. Calculator
Never rely on the LLM for exact arithmetic.

### 5. Coding sandbox
Write -> compile/test -> inspect errors -> fix -> retry, with strict sandboxing.

### 6. Android control
Safe intents first. Optional AccessibilityService for UI automation with explicit user permission.

### 7. Vision
Add a verified small local vision model later. Do not pretend the current text model is multimodal.

### 8. File intelligence
Use SAF to import TXT/MD/CSV/JSON. Add PDF extraction only after a verified dependency is selected.

### 9. Voice
Wake detector -> STT -> planner -> tools -> answer -> TTS. Conversation mode should keep a short follow-up window.

### 10. Verification
Claims requiring current facts should trigger web retrieval; exact calculations should trigger calculator; tool results should be passed back into the local model.

## Hardware strategy
Keep heavy models off the phone unless RAM permits. Prefer small specialist components and retrieval over loading giant context.

## Android reality
A fully powered-off phone cannot run the app. Android/OEM background restrictions can also interrupt microphone services.
