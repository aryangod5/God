plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.godai.local"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.godai.local"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "3.0"
    }

    buildFeatures {
        buildConfig = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")

    // On-device GGUF inference.
    implementation("dev.ffmpegkit-maintained:llama-android:0.1.1")

    // Offline speech recognition.
    implementation("com.alphacephei:vosk-android:0.3.75")
}
