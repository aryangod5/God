package com.godai.local.tools

import java.net.HttpURLConnection
import java.net.URI

class WebTool {
    fun search(query: String): String {
        return try {
            val url = URI.create(
                "https://html.duckduckgo.com/html/?q=" +
                    java.net.URLEncoder.encode(query, "UTF-8")
            ).toURL()
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "GOD-AI/3.0")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val cleaned = text.replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ")
            cleaned.take(6000)
        } catch (e: Exception) {
            "Web search failed: ${e.message ?: "network error"}"
        }
    }
}
