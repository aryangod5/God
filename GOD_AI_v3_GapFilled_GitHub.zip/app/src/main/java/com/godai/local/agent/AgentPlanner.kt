package com.godai.local.agent

import com.godai.local.memory.MemoryStore
import com.godai.local.tools.CalculatorTool
import com.godai.local.tools.WebTool

class AgentPlanner(
    private val calculator: CalculatorTool,
    private val web: WebTool,
    private val memory: MemoryStore
) {
    private val maxSteps = 4

    fun run(userText: String): String {
        memory.add("user", userText)

        val lower = userText.lowercase()

        val result = when {
            looksLikeMath(lower) -> calculator.calculate(userText)
            lower.startsWith("search ") -> web.search(userText.removePrefix("search ").trim())
            lower.contains("remember that") -> {
                memory.add("memory", userText)
                "Saved locally."
            }
            lower.contains("what do you remember") -> memory.relevant(userText).ifEmpty {
                "I don't have a matching local memory yet."
            }
            else -> "Local agent received: $userText\n\nThe next layer is the local LLM response engine."
        }

        memory.add("assistant", result)
        return result
    }

    private fun looksLikeMath(s: String): Boolean =
        s.any { it.isDigit() } &&
            s.any { it in "+-*/%^" } &&
            s.all { it.isDigit() || it.isWhitespace() || it in "+-*/%^()." }
}
