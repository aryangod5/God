package com.godai.local

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.godai.local.core.GodCore
import com.godai.local.ui.FutureHud
import com.godai.local.voice.GodVoiceService

class MainActivity : ComponentActivity() {
    private lateinit var hud: FutureHud

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hud = FutureHud(this)
        setContentView(hud)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }

        GodCore.initialize(applicationContext)
        hud.setStatus("GOD AI • LOCAL AGENT READY")
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
