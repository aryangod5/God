package com.godai.local.core

import android.content.Context
import com.godai.local.agent.AgentPlanner
import com.godai.local.memory.MemoryStore
import com.godai.local.tools.CalculatorTool
import com.godai.local.tools.WebTool

object GodCore {
    lateinit var appContext: Context
        private set

    lateinit var memory: MemoryStore
        private set

    lateinit var planner: AgentPlanner
        private set

    fun initialize(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext
        memory = MemoryStore(appContext)
        planner = AgentPlanner(
            calculator = CalculatorTool(),
            web = WebTool(),
            memory = memory
        )
    }

    fun handle(text: String): String {
        return planner.run(text)
    }
}
