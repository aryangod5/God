package com.godai.local.tools

class CalculatorTool {
    fun calculate(input: String): String {
        return try {
            val value = Parser(input).parse()
            if (value.isFinite()) value.toString() else "Calculation is not finite."
        } catch (_: Exception) {
            "I couldn't safely calculate that expression."
        }
    }

    private class Parser(private val s: String) {
        private var p = 0
        private fun skip() { while (p < s.length && s[p].isWhitespace()) p++ }

        fun parse(): Double {
            val v = expression()
            skip()
            if (p != s.length) error("Unexpected input")
            return v
        }

        private fun expression(): Double {
            var v = term()
            while (true) {
                skip()
                if (p >= s.length) return v
                when (s[p]) {
                    '+' -> { p++; v += term() }
                    '-' -> { p++; v -= term() }
                    else -> return v
                }
            }
        }

        private fun term(): Double {
            var v = power()
            while (true) {
                skip()
                if (p >= s.length) return v
                when (s[p]) {
                    '*' -> { p++; v *= power() }
                    '/' -> { p++; v /= power() }
                    else -> return v
                }
            }
        }

        private fun power(): Double {
            var v = unary()
            skip()
            if (p < s.length && s[p] == '^') {
                p++
                v = kotlin.math.pow(v, unary())
            }
            return v
        }

        private fun unary(): Double {
            skip()
            if (p < s.length && s[p] == '+') { p++; return unary() }
            if (p < s.length && s[p] == '-') { p++; return -unary() }
            if (p < s.length && s[p] == '(') {
                p++
                val v = expression()
                skip()
                if (p >= s.length || s[p] != ')') error("Missing )")
                p++
                return v
            }
            val start = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (start == p) error("Number expected")
            return s.substring(start, p).toDouble()
        }
    }
}
