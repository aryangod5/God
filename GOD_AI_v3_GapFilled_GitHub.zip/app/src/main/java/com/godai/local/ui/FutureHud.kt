package com.godai.local.ui

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class FutureHud(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var status = "STANDBY"
    private var phase = 0f

    init {
        setBackgroundColor(Color.BLACK)
        postInvalidateOnAnimation()
    }

    fun setStatus(value: String) {
        status = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = Color.rgb(70, 180, 255)

        for (r in floatArrayOf(90f, 150f, 230f, 320f)) {
            canvas.drawCircle(cx, cy, r, paint)
        }

        for (i in 0 until 12) {
            val a = phase + i * Math.PI.toFloat() / 6f
            val x = cx + cos(a) * 320f
            val y = cy + sin(a) * 320f
            paint.style = Paint.Style.FILL
            canvas.drawCircle(x, y, 5f, paint)
            paint.style = Paint.Style.STROKE
        }

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 22f
        canvas.drawText("GOD AI", cx, cy - 12f, paint)
        paint.textSize = 14f
        canvas.drawText(status, cx, cy + 20f, paint)

        paint.textAlign = Paint.Align.LEFT
        paint.textSize = 11f
        canvas.drawText("LOCAL • AGENT • NO API", 24f, height - 28f, paint)

        phase += 0.008f
        postInvalidateOnAnimation()
    }
}
