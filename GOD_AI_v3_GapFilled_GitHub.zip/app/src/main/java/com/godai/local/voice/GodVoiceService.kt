package com.godai.local.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.godai.local.core.GodCore
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

class GodVoiceService : Service(), RecognitionListener {
    private var speech: SpeechService? = null
    private var recognizer: Recognizer? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, notification())
        GodCore.initialize(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Full Vosk model provisioning is intentionally deferred to the model manager.
        return START_STICKY
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("god_voice", "GOD AI Voice", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, "god_voice")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("GOD AI")
            .setContentText("Voice agent ready")
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        speech?.stop()
        recognizer?.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onPartialResult(hypothesis: String?) {}
    override fun onResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(e: Exception?) {}
    override fun onTimeout() {}
}
