package com.godai.local.memory

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MemoryStore(private val context: Context) {
    private val file = File(context.filesDir, "god_memory.json")

    @Synchronized
    fun add(role: String, text: String) {
        val arr = read()
        arr.put(JSONObject().apply {
            put("role", role)
            put("text", text.take(8000))
            put("time", System.currentTimeMillis())
        })
        while (arr.length() > 200) arr.remove(0)
        file.writeText(arr.toString())
    }

    @Synchronized
    fun relevant(query: String): String {
        val words = query.lowercase()
            .split(Regex("\\W+")).filter { it.length >= 3 }.toSet()
        val arr = read()
        val scored = mutableListOf<Pair<Int, String>>()

        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val text = o.optString("text")
            val score = words.count { text.lowercase().contains(it) }
            if (score > 0) scored += score to text
        }

        return scored.sortedByDescending { it.first }
            .take(8)
            .joinToString("\n") { it.second }
    }

    private fun read(): JSONArray =
        if (file.exists()) JSONArray(file.readText()) else JSONArray()
}
