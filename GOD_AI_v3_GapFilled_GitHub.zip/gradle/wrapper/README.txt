The GitHub workflow uses gradle/actions/setup-gradle, so the repository does not depend on a locally bundled Gradle distribution.
If a classic Gradle wrapper JAR is desired, generate it with:
gradle wrapper --gradle-version 8.13
The wrapper scripts are included for convenience, but GitHub Actions builds with the configured Gradle setup action.
