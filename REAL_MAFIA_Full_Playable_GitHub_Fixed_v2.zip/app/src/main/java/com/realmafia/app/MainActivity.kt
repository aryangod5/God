package com.realmafia.app

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var video: PlayerView
    private lateinit var hero: ImageView
    private lateinit var mission: TextView
    private lateinit var location: TextView
    private lateinit var action: Button
    private var x = 0f
    private var run = false
    private var scene = 0
    private val scenes = listOf("media/city_night.mp4", "media/sidewalk.mp4", "media/road.mp4", "media/aerial.mp4")
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildUi()
        setupVideo()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = PlayerView(this).apply { useController = false; resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM }
        root.addView(video, FrameLayout.LayoutParams(-1,-1))

        hero = ImageView(this).apply {
            setImageResource(com.realmafia.app.R.drawable.player)
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = .98f
            contentDescription = "Realistic player character"
        }
        val hp = FrameLayout.LayoutParams(dp(190), dp(440), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(12) }
        root.addView(hero, hp)

        mission = label("MAIN MISSION\nReach the contact point", 16f, Color.WHITE).apply { setBackgroundColor(0xAA101010.toInt()); setPadding(dp(14),dp(10),dp(14),dp(10)) }
        root.addView(mission, FrameLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { leftMargin=dp(18); topMargin=dp(18) })

        location = label("● DOWNTOWN  •  18:42", 13f, 0xFFFFB52E.toInt())
        root.addView(location, FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.END).apply { rightMargin=dp(18); topMargin=dp(22) })

        val joystick = TextView(this).apply { text="◀   ●   ▶\n\n      ▲"; textSize=19f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(0x66101010); setPadding(dp(18),dp(8),dp(18),dp(8)) }
        root.addView(joystick, FrameLayout.LayoutParams(dp(140),dp(125),Gravity.BOTTOM or Gravity.START).apply{leftMargin=dp(18);bottomMargin=dp(18)})
        joystick.setOnTouchListener { _, e ->
            if(e.action==MotionEvent.ACTION_DOWN || e.action==MotionEvent.ACTION_MOVE){
                val local = e.x - joystick.width/2f
                move(local/8f)
            }
            true
        }

        action = button("ACTION")
        root.addView(action, FrameLayout.LayoutParams(dp(110),dp(60),Gravity.BOTTOM or Gravity.END).apply{rightMargin=dp(20);bottomMargin=dp(90)})
        action.setOnClickListener { nextScene("Action complete • continue to next area") }

        val runBtn = button("RUN")
        root.addView(runBtn, FrameLayout.LayoutParams(dp(90),dp(58),Gravity.BOTTOM or Gravity.END).apply{rightMargin=dp(30);bottomMargin=dp(20)})
        runBtn.setOnTouchListener { _, e -> run = e.action != MotionEvent.ACTION_UP && e.action != MotionEvent.ACTION_CANCEL; true }

        val interact = button("LOOK")
        root.addView(interact, FrameLayout.LayoutParams(dp(90),dp(58),Gravity.TOP or Gravity.END).apply{rightMargin=dp(20);topMargin=dp(90)})
        interact.setOnClickListener { hero.animate().rotationY(if(hero.rotationY==0f) 10f else 0f).setDuration(180).start() }

        setContentView(root)
    }

    private fun setupVideo() {
        player = ExoPlayer.Builder(this).build()
        video.player = player
        player.repeatMode = Player.REPEAT_MODE_ONE
        playScene(0)
        player.addListener(object: Player.Listener { override fun onPlaybackStateChanged(state:Int){ if(state==Player.STATE_READY) preloadNext() } })
    }

    private fun playScene(index:Int) {
        scene = index.mod(scenes.size)
        val uri = "asset:///${scenes[scene]}"
        player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady=true
        location.text = listOf("● DOWNTOWN • 18:42","● MARKET STREET • 18:44","● WEST ROAD • 18:46","● CITY OVERLOOK • 18:48")[scene]
        hero.translationX = 0f; x=0f
    }
    private fun preloadNext() { /* ExoPlayer keeps the active media hot; next scene is selected instantly by the director. */ }
    private fun nextScene(msg:String){ mission.text = "MISSION UPDATE\n$msg"; playScene(scene+1); pulse() }
    private fun move(delta:Float){ val speed=if(run) 2.2f else 1.1f; x=(x+delta*speed).coerceIn(-180f,180f); hero.translationX=x; hero.scaleX=1f+min(0.05f, kotlin.math.abs(delta)/2500f); hero.scaleY=hero.scaleX }
    private fun pulse(){ action.animate().scaleX(1.08f).scaleY(1.08f).setDuration(120).withEndAction{action.animate().scaleX(1f).scaleY(1f).setDuration(120).start()}.start(); try { val v= getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator; v.vibrate(android.os.VibrationEffect.createOneShot(35,60)) } catch(_:Exception){} }
    private fun label(t:String,s:Float,c:Int)=TextView(this).apply{text=t;textSize=s.toFloat();setTextColor(c);typeface=android.graphics.Typeface.DEFAULT_BOLD}
    private fun button(t:String)=Button(this).apply{text=t;textSize=12f;setTextColor(Color.WHITE);setBackgroundColor(0xAA151515.toInt());isAllCaps=false}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onDestroy(){ super.onDestroy(); if(::player.isInitialized) player.release(); handler.removeCallbacksAndMessages(null) }
}
