# REAL MAFIA — Full Playable Video Prototype

This package is a lightweight Android prototype using real moving video environments plus a photorealistic player-image layer and touch gameplay logic. It is intentionally not a 3D engine project.

## What is playable
- Landscape third-person presentation
- Real 720p/30fps video environments bundled locally
- Realistic photographic player layer
- Touch movement area and RUN control
- ACTION button changes to another compatible video scene
- LOOK button subtly turns the character
- Mission/location HUD and haptic feedback
- No internet required after installation

## Important
This is a playable vertical-slice prototype, not a complete open-world AAA game. The video method uses prepared camera angles, so it cannot provide unrestricted 360-degree movement like a real-time 3D world.

## Build on GitHub
If you already have the `build-from-zip.yml` workflow from the earlier REAL MAFIA setup, upload this ZIP to the repository and run that workflow. The workflow extracts the ZIP and builds `app-debug.apk`.

If starting a brand-new repository, GitHub will not execute a workflow that is only inside a ZIP. Create `.github/workflows/build-from-zip.yml` once (the reference workflow is included in this package under `GITHUB_WORKFLOW_TO_COPY.yml`), then upload this ZIP.
