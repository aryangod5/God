# REAL MAFIA — one-ZIP GitHub import

1. Create a new empty GitHub repository.
2. Upload `REAL_MAFIA_GitHub_Ready.zip` to the repository.
3. Open **Actions**.
4. Select **Build REAL MAFIA from ZIP**.
5. Press **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed run and download the `real-mafia-debug-apk` artifact.
8. Extract the artifact and install `app-debug.apk` on Android.

The workflow extracts the project ZIP automatically before building.

Important: this is a buildable prototype foundation. The finished cinematic video library and high-quality character/NPC assets are not bundled in this small ZIP yet.
