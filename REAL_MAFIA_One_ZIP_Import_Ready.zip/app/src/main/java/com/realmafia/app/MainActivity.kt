package com.realmafia.app

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var state: WorldState
    private lateinit var director: WorldDirector
    private lateinit var save: SaveManager
    private lateinit var haptics: HapticManager

    private lateinit var status: TextView
    private lateinit var mission: TextView
    private lateinit var fallback: TextView
    private lateinit var playerAvatar: TextView
    private lateinit var playerView: PlayerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        save = SaveManager(this)
        state = save.load()
        director = WorldDirector(state)
        haptics = HapticManager(this)

        status = findViewById(R.id.status)
        mission = findViewById(R.id.mission)
        fallback = findViewById(R.id.worldFallback)
        playerAvatar = findViewById(R.id.playerAvatar)
        playerView = findViewById(R.id.playerView)

        player = ExoPlayer.Builder(this).build()
        playerView.player = player

        findViewById<Button>(R.id.actionLeft).setOnClickListener { choose("left") }
        findViewById<Button>(R.id.actionMain).setOnClickListener { choose("action") }
        findViewById<Button>(R.id.actionRight).setOnClickListener { choose("right") }

        updateHud()
        playSceneIfConfigured(state.sceneId)
    }

    private fun choose(action: String) {
        haptics.tap()

        when (action) {
            "left", "right" -> {
                val next = director.nextScene(action)
                director.apply(next, action)
            }
            else -> {
                state.playerAction = when (state.playerAction) {
                    "idle" -> "walk"
                    "walk" -> "run"
                    "run" -> "crouch"
                    "crouch" -> "jump"
                    else -> "idle"
                }
                state.progress += 1
            }
        }

        save.save(state)
        updateHud()
        playSceneIfConfigured(state.sceneId)
    }

    private fun updateHud() {
        status.text =
            "REAL MAFIA  •  ${state.location.uppercase()}  •  ${state.timeOfDay.uppercase()}"
        mission.text =
            "MISSION: ${state.mission.replace('_', ' ').uppercase()}  •  ACTION: ${state.playerAction.uppercase()}"

        playerAvatar.translationX = when (state.playerAction) {
            "walk" -> -30f
            "run" -> 45f
            "crouch" -> 0f
            "jump" -> 0f
            else -> 0f
        }

        playerAvatar.translationY = when (state.playerAction) {
            "jump" -> 25f
            "crouch" -> 125f
            else -> 80f
        }
    }

    private fun playSceneIfConfigured(scene: String) {
        /*
         * Add legally owned media URLs in assets/media/scenes.json.
         * Until real media is configured, the lightweight fallback world remains visible.
         */
        val url = sceneUrl(scene)
        if (url.isNullOrBlank()) {
            playerView.visibility = View.GONE
            fallback.visibility = View.VISIBLE
            return
        }

        playerView.visibility = View.VISIBLE
        fallback.visibility = View.GONE
        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
        player.prepare()
        player.playWhenReady = true
    }

    private fun sceneUrl(scene: String): String? {
        // Keep empty until you add your own hosted/legally licensed media.
        return null
    }

    override fun onStop() {
        super.onStop()
        player.pause()
        save.save(state)
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
