package com.realmafia.app

import android.content.Context

class SaveManager(context: Context) {
    private val prefs = context.getSharedPreferences("real_mafia_save", Context.MODE_PRIVATE)

    fun save(state: WorldState) {
        prefs.edit()
            .putString("scene", state.sceneId)
            .putString("location", state.location)
            .putString("mission", state.mission)
            .putString("time", state.timeOfDay)
            .putString("weather", state.weather)
            .putString("playerAction", state.playerAction)
            .putInt("alert", state.alert)
            .putInt("progress", state.progress)
            .apply()
    }

    fun load(): WorldState = WorldState(
        sceneId = prefs.getString("scene", "intro") ?: "intro",
        location = prefs.getString("location", "safehouse") ?: "safehouse",
        mission = prefs.getString("mission", "first_contact") ?: "first_contact",
        timeOfDay = prefs.getString("time", "night") ?: "night",
        weather = prefs.getString("weather", "clear") ?: "clear",
        playerAction = prefs.getString("playerAction", "idle") ?: "idle",
        alert = prefs.getInt("alert", 0),
        progress = prefs.getInt("progress", 0)
    )
}
