package com.realmafia.app

data class WorldState(
    var sceneId: String = "intro",
    var location: String = "safehouse",
    var mission: String = "first_contact",
    var timeOfDay: String = "night",
    var weather: String = "clear",
    var playerAction: String = "idle",
    var alert: Int = 0,
    var progress: Int = 0
)
