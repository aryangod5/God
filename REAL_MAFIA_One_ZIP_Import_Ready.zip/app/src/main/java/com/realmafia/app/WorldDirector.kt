package com.realmafia.app

class WorldDirector(private val state: WorldState) {

    fun nextScene(action: String): String {
        return when (state.sceneId) {
            "intro" -> when (action) {
                "left" -> "street_left"
                "right" -> "street_right"
                else -> "contact"
            }
            "street_left" -> when (action) {
                "left" -> "alley_night"
                "right" -> "parking_night"
                else -> "building_night"
            }
            "street_right" -> when (action) {
                "left" -> "commercial_night"
                "right" -> "road_night"
                else -> "parking_night"
            }
            else -> when (action) {
                "left" -> "street_left"
                "right" -> "street_right"
                else -> "contact"
            }
        }
    }

    fun apply(scene: String, action: String) {
        state.sceneId = scene
        state.playerAction = action
        state.location = when {
            scene.contains("alley") -> "narrow_street"
            scene.contains("parking") -> "parking"
            scene.contains("building") -> "building"
            scene.contains("commercial") -> "commercial_street"
            scene.contains("road") || scene.contains("street") -> "city_road"
            else -> "safehouse"
        }
        state.progress += 1
    }

    fun setTime(time: String) {
        state.timeOfDay = time
    }

    fun setWeather(weather: String) {
        state.weather = weather
    }
}
