Place media planning files here.

Do not commit copyrighted or unlicensed footage.

The initial APK intentionally uses a fallback scene. Add your own licensed/owned media and connect the scene IDs in the Kotlin media loader when the media pipeline is ready.
