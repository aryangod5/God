# REAL MAFIA — GitHub-ready Android prototype

This repository is a buildable Android foundation for the REAL MAFIA video-driven third-person game concept.

## What is included

- Native Kotlin Android project
- Gradle build configuration
- GitHub Actions workflow that builds `app-debug.apk`
- Lightweight World Director/state system
- Save/progression system
- Haptic feedback
- Third-person player placeholder
- Walking/run/crouch/jump state demonstration
- Scene branching
- Day/night/world-state fields
- Media3/ExoPlayer integration point
- Media scene manifest
- Fallback visual scene so the APK can launch before media is added

## Important

This ZIP does **not** contain a finished AAA game or hundreds of finished cinematic videos. Those are media assets that must be created/processed separately. The project is structured so those assets can be added later.

Only add videos/images you own or have permission/license to use.

## Build on GitHub

1. Create a new empty GitHub repository.
2. Extract this ZIP on your phone/computer.
3. Upload the **contents of the extracted folder** to the repository root. Do not upload the ZIP as the only repository file.
4. Open the repository's **Actions** tab.
5. Select **Build REAL MAFIA APK**.
6. Press **Run workflow**.
7. When the workflow finishes, open the workflow run.
8. Under **Artifacts**, download `real-mafia-debug-apk`.
9. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

The workflow installs Java 17, Android SDK 35 and Gradle 8.13 automatically.

## Adding media later

Put scene metadata in:

`app/src/main/assets/media/scenes.json`

The current Kotlin demo intentionally leaves `sceneUrl()` empty so the APK is buildable without external media.

For the full media version, the next development step is to connect each scene ID to its legally owned/hosted video URL and then add the processed player/NPC assets.

## Project identity

Application ID: `com.realmafia.app`

App name: `REAL MAFIA`

Minimum Android version: Android 6.0 / API 23

Target Android version: API 35
