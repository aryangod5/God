# Media pipeline plan

Recommended scene variants:

- day
- evening
- night
- clear
- rain
- fog
- slow
- normal
- transition/exit
- transition/entrance

Every scene should carry:

- scene ID
- location family
- time of day
- weather
- entrance direction
- exit direction
- camera type
- compatible next scenes

This lets the World Director select visually compatible clips instead of randomly switching between unrelated footage.

For player animation, prefer a consistent character captured/rendered across the full pose set so the face, clothing, lighting and proportions remain stable.
