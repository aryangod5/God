# REAL MAFIA architecture

The intended low-resource design is:

Environment video
    +
lightweight player/NPC layers
    +
World Director
    +
touch input
    +
save state
    =
game-like experience

The phone should decode/play only the currently relevant media and keep the next likely scene ready. Heavy video generation or large-scale asset production should happen before distribution, not live on a low-end phone.

The World Director should keep time/weather/location compatible so a left turn cannot accidentally switch from night footage to daytime footage.

For true free camera rotation, a lightweight 3D character is more capable than a 2D video layer. The current prototype deliberately uses lightweight state/visual placeholders so the build stays small.
